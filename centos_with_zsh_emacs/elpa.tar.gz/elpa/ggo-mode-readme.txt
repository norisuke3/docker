A major mode for editing gengetopt files.

Modify `ggo-skeleton' to suit your format.

Should work with Emacs version 21 and later.  Works with
gengetopt 2.22.4.  May or may not work with previous versions.
